import os
from dotenv import load_dotenv
from langchain_community.document_loaders import PyPDFLoader
from langchain_core.documents import Document
from langchain_text_splitters import TokenTextSplitter
from langchain_huggingface import HuggingFaceEndpoint, HuggingFaceEmbeddings
from langchain_core.prompts import PromptTemplate
from langchain_community.vectorstores import FAISS
from langchain_core.runnables import RunnablePassthrough
from langchain_core.output_parsers import StrOutputParser
from src.prompt import *

# HuggingFace Hub authentication
load_dotenv()
HF_API_KEY = os.getenv("HF_API_KEY")
if HF_API_KEY:
    os.environ["HUGGINGFACEHUB_API_TOKEN"] = HF_API_KEY
else:
    print("WARNING: HF_API_KEY not found in .env file.")

# ============================================
# MODEL CONFIGURATION
# ============================================
# Mistral Instruct is excellent for this. 
# If it's too slow, try "google/flan-t5-large" (faster but less smart)
QUESTION_GEN_MODEL = "google/flan-t5-large"
ANSWER_GEN_MODEL   = "google/flan-t5-large"

EMBEDDINGS_MODEL = "sentence-transformers/all-MiniLM-L6-v2"

QUESTION_GEN_TEMPERATURE = 0.5 # Slightly higher creativity for questions
ANSWER_GEN_TEMPERATURE = 0.1   # Low temperature for factual answers
# ============================================

def file_processing(file_path):
    # Load data from PDF
    loader = PyPDFLoader(file_path)
    data = loader.load()

    question_gen = ''

    for page in data:
        question_gen += page.page_content
        
    # Using gpt2 tokenizer is fine, but let's be safe with tiktoken logic
    splitter_ques_gen = TokenTextSplitter(
        model_name="gpt2",
        chunk_size=10000,
        chunk_overlap=200
    )

    chunks_ques_gen = splitter_ques_gen.split_text(question_gen)
    document_ques_gen = [Document(page_content=t) for t in chunks_ques_gen]

    splitter_ans_gen = TokenTextSplitter(
        model_name="gpt2",
        chunk_size=1000,
        chunk_overlap=100
    )

    document_answer_gen = splitter_ans_gen.split_documents(document_ques_gen)

    return document_ques_gen, document_answer_gen

def llm_pipeline(file_path):
    document_ques_gen, document_answer_gen = file_processing(file_path)

    llm_ques_gen_pipeline = HuggingFaceEndpoint(
    repo_id=QUESTION_GEN_MODEL,
    temperature=QUESTION_GEN_TEMPERATURE,
    max_new_tokens=1024
    )


    PROMPT_QUESTIONS = PromptTemplate(template=prompt_template, input_variables=["text"])
    
    REFINE_PROMPT_QUESTIONS = PromptTemplate(
        input_variables=["existing_answer", "text"],
        template=refine_template,
    )

    # Refine Chain Logic
    ques = ""
    for i, doc in enumerate(document_ques_gen):
        if i == 0:
            ques = llm_ques_gen_pipeline.invoke(PROMPT_QUESTIONS.format(text=doc.page_content))
        else:
            refined_input = REFINE_PROMPT_QUESTIONS.format(existing_answer=ques, text=doc.page_content)
            ques = llm_ques_gen_pipeline.invoke(refined_input)

    # Initialize Embeddings & Vector Store
    embeddings = HuggingFaceEmbeddings(model_name=EMBEDDINGS_MODEL)
    vector_store = FAISS.from_documents(document_answer_gen, embeddings)

    # Initialize LLM for Answer Generation
    llm_answer_gen = HuggingFaceEndpoint(
    repo_id=ANSWER_GEN_MODEL,
    temperature=ANSWER_GEN_TEMPERATURE,
    max_new_tokens=512
    )

    # Filter questions
    ques_list = ques.split("\n")
    filtered_ques_list = [element for element in ques_list if element.strip().endswith('?') or element.strip().endswith('.')]

    # Retrieval Chain
    retriever = vector_store.as_retriever()
    
    answer_prompt = PromptTemplate(
        input_variables=["context", "question"],
        template="Based on the following context, answer the question strictly.\n\nContext: {context}\n\nQuestion: {question}\n\nAnswer:"
    )
    
    # LCEL Chain Construction
    answer_generation_chain = (
        {"context": retriever, "question": RunnablePassthrough()} 
        | answer_prompt 
        | llm_answer_gen 
        | StrOutputParser()
    )

    return answer_generation_chain, filtered_ques_list