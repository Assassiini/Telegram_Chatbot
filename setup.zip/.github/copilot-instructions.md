## Copilot / AI Agent Instructions for Interview Question Creator

This repository is a small FastAPI app that accepts a PDF, extracts text, generates practice questions with a summarization/refine chain, then answers them using a FAISS retriever. Use these notes to make targeted, low-risk edits and run/debug the app quickly.

Key files to inspect
- `app.py` — web server & endpoints. Uploads files to `static/docs/`, triggers analysis and writes `static/output/QA.csv`.
- `src/helper.py` — core LLM pipeline, document splitting, vector store creation, and RetrievalQA chain construction.
- `src/prompt.py` — prompt templates used by the summarization/refine workflow (`prompt_template`, `refine_template`).
- `templates/index.html` — front-end UX and client-side flow (POST `/upload` then `/analyze`). Example JS handlers are in this file.
- `requirements.txt` — packages required (note: `faiss-cpu` may need special handling on Windows).

Quick architecture summary (big picture)
- Client (browser) -> POST `/upload` (saves PDF to `static/docs/`) -> POST `/analyze` (calls `get_csv`) -> `llm_pipeline` in `src/helper.py`.
- `llm_pipeline` does: PDF load (PyPDFLoader) -> token-based splitting (TokenTextSplitter) -> question generation via a `load_summarize_chain(chain_type='refine')` with `prompt_template` and `refine_template` -> produces a list of questions -> builds FAISS vector store from answer-oriented chunks -> returns a RetrievalQA chain and filtered questions.
- `get_csv` iterates questions and calls the retrieval chain to produce answers, writing them to `static/output/QA.csv` for download.

Run & debug
- Environment: create a virtualenv/conda and install `requirements.txt` (README shows conda steps). Ensure `.env` contains `HF_API_KEY` (HuggingFace API token for private models). The code uses `python-dotenv`.
- **Model selection**: Edit the three model variables in `src/helper.py` (lines 27-29):
  - `QUESTION_GEN_MODEL` — model for question generation (e.g., `"mistralai/Mistral-7B-Instruct-v0.1"`, `"meta-llama/Llama-2-7b-chat-hf"`)
  - `ANSWER_GEN_MODEL` — model for answer generation (typically the same or smaller)
  - `EMBEDDINGS_MODEL` — embedding model (e.g., `"sentence-transformers/all-MiniLM-L6-v2"`)
  - Examples: Mistral, Llama-2, Falcon, or any HuggingFace Hub model supporting inference API.
- Start server (development):
  - Recommended: `uvicorn app:app --reload --host 0.0.0.0 --port 8080` (equivalent to how `app.py` runs in `__main__`).
  - Alternatively, run `python app.py`.
- Logs: the app uses `print()` in `get_csv` and `ques_gen_chain` (verbose=True) — watch console output for chain activity.

Project-specific conventions & patterns
- Prompt separation: prompts live in `src/prompt.py` and are passed into `PromptTemplate` in `src/helper.py` — change wording there, not directly inside `helper.py` when editing prompts.
- Chunking strategy:
  - Questions generation uses TokenTextSplitter chunk_size=10000, overlap=200 (very large chunks) with `gpt2` tokenizer.
  - Answer generation uses chunk_size=1000, overlap=100 and creates documents used by FAISS.
  - If you tweak chunk sizes, verify memory/FAISS behavior and downstream answer quality.
- LLM usage: HuggingFaceEndpoint is instantiated in `src/helper.py` (model names and temperatures in config block at top). To change models:
  - Edit `QUESTION_GEN_MODEL`, `ANSWER_GEN_MODEL` constants (lines 27-28).
  - Adjust `QUESTION_GEN_TEMPERATURE`, `ANSWER_GEN_TEMPERATURE` as needed (lines 30-31).
  - Optional: modify `max_new_tokens` in the `model_kwargs` dict for each LLM instantiation.
- Vector store: FAISS is constructed from `document_answer_gen` using HuggingFaceEmbeddings. This is in-memory and not persisted — expect rebuilds on each request.

Integration points & external dependencies
- HuggingFace Hub API via `langchain-huggingface` (HuggingFaceEndpoint, HuggingFaceEmbeddings). Ensure `HF_API_KEY` in `.env` for authentication.
- FAISS (`faiss-cpu`) — on Windows this can be tricky; prefer Linux/macOS or use `pip` wheels that match your Python version.
- PyPDF (PyPDF2/PyPDFLoader) — PDF loading is synchronous in helper; file reading is handled by FastAPI upload endpoint which writes bytes to `static/docs/`.
- Open-source LLMs are called via HuggingFace Inference API (requires internet and valid API token).

Important behavioral notes (discoverable from code)
- Frontend shows "Max No. of Pages is 5" but the server does not enforce page limits. Page-limit checks are only UI-level.
- Uploaded files are saved using the provided filename to `static/docs/` without sanitization — be cautious when modifying file I/O. Consider validating/sanitizing filenames if exposing to untrusted users.
- Output CSV is always written to `static/output/QA.csv` (overwrites previous runs). If parallel runs are needed, change filename strategy.
- Large or slow models may timeout; consider using smaller models or increasing timeout settings if needed.

Quick editing checklist for common tasks
- Change model: edit `QUESTION_GEN_MODEL`, `ANSWER_GEN_MODEL`, or `EMBEDDINGS_MODEL` constants at the top of `src/helper.py`.
- Change temperature/generation params: edit constants in the config block (lines 27-31) in `src/helper.py`.
- Change prompt wording: edit `src/prompt.py` and keep input variables intact (`{text}`, `{existing_answer}`).
- Persist FAISS index: add a persistence step (FAISS has serialization methods) and adjust startup to load the index.
- Add page-limit enforcement: add page counting when loading PDF in `src/helper.py` or validate in `app.py` upload endpoint.

Examples (concrete locations)
- To find where questions are generated: see `ques_gen_chain = load_summarize_chain(..., question_prompt=PROMPT_QUESTIONS, refine_prompt=REFINE_PROMPT_QUESTIONS)` in `src/helper.py`.
- To change model: edit lines 27-29 in `src/helper.py`:
  ```python
  QUESTION_GEN_MODEL = "meta-llama/Llama-2-7b-chat-hf"
  ANSWER_GEN_MODEL = "meta-llama/Llama-2-7b-chat-hf"
  EMBEDDINGS_MODEL = "sentence-transformers/all-mpnet-base-v2"
  ```
- To change where files are saved: review the `base_folder = 'static/docs/'` logic in `app.py` and `get_csv`.

Safety & troubleshooting
- If HuggingFace API calls fail, check that `HF_API_KEY` is set in `.env` and the model exists on HuggingFace Hub.
- If FAISS import fails on Windows, try installing `faiss-cpu` from prebuilt wheels or use a Linux dev container.
- If you see empty question lists, print the `ques` value right after `ques = ques_gen_chain.run(document_ques_gen)` (the code already splits by newline and filters punctuation).
- For models requiring gated access (e.g., Llama), accept the terms on HuggingFace and use an API token with permission.

If something here is unclear or you'd like me to: (1) merge with an existing Copilot file if you have one elsewhere, (2) add examples of small edits (e.g., change model to gpt-4), or (3) create a short test harness, tell me which and I will update this file.

---
Files referenced: `app.py`, `src/helper.py`, `src/prompt.py`, `templates/index.html`, `requirements.txt`, `README.md`.
