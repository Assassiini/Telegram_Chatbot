# HuggingFace Model Selection Guide

This document helps you choose open-source models from HuggingFace Hub for the Interview Question Creator.

## Quick Start

Edit these three constants in `src/helper.py` (lines 27-29):

```python
QUESTION_GEN_MODEL = "your-model-name-here"
ANSWER_GEN_MODEL = "your-model-name-here"
EMBEDDINGS_MODEL = "sentence-transformers/all-MiniLM-L6-v2"
```

## Model Categories

### Question Generation Models (QUESTION_GEN_MODEL)
Use **larger, instruction-following models** that can generate coherent questions from text.

**Recommended options:**
- `mistralai/Mistral-7B-Instruct-v0.1` — Fast, versatile, good quality (⭐ Best start)
- `meta-llama/Llama-2-7b-chat-hf` — Smaller Llama, good for questions (requires HF token acceptance)
- `google/flan-t5-large` — Smaller, fast, good for summarization & questions
- `tiiuae/falcon-7b-instruct` — Good instruction-following, efficient
- `meta-llama/Llama-2-13b-chat-hf` — Larger Llama (slower but better quality)
- `mistralai/Mixtral-8x7B-Instruct-v0.1` — Larger mixture-of-experts (very slow, highest quality)

### Answer Generation Models (ANSWER_GEN_MODEL)
Use the **same model or a smaller one**. Answers need less complexity than question generation.

**Recommended options:**
- `google/flan-t5-base` — Small, fast, good for retrieval-based answering
- `mistralai/Mistral-7B-Instruct-v0.1` — Same as question gen for consistency
- `meta-llama/Llama-2-7b-chat-hf` — Same as question gen
- `tiiuae/falcon-7b-instruct` — Fast and efficient

### Embedding Models (EMBEDDINGS_MODEL)
Use **sentence-transformer models** for FAISS vector store. These are not LLMs but specialized for embeddings.

**Recommended options:**
- `sentence-transformers/all-MiniLM-L6-v2` — Small, fast, good quality (⭐ Default, best choice)
- `sentence-transformers/all-mpnet-base-v2` — Larger, better quality (slower)
- `sentence-transformers/paraphrase-MiniLM-L6-v2` — Small, optimized for paraphrase
- `BAAI/bge-small-en-v1.5` — Compact, high-quality embeddings

## Setup Instructions

### 1. Prerequisites
- HuggingFace API token: https://huggingface.co/settings/tokens
- Create a **read-only token** (no write permissions needed)
- Save to `.env`: `HF_API_KEY=hf_xxxxxxxxxxxxx`

### 2. If model requires approval
Some models (e.g., Llama-2) need you to accept terms on HuggingFace:
1. Go to the model page (e.g., https://huggingface.co/meta-llama/Llama-2-7b-chat-hf)
2. Click "Access repository" and accept terms
3. Make sure your token has access (use a user token, not write-only)

### 3. Edit and test
Edit `src/helper.py`:
```python
QUESTION_GEN_MODEL = "mistralai/Mistral-7B-Instruct-v0.1"
ANSWER_GEN_MODEL = "mistralai/Mistral-7B-Instruct-v0.1"
EMBEDDINGS_MODEL = "sentence-transformers/all-MiniLM-L6-v2"
```

Then run:
```bash
python app.py
```

Visit `http://localhost:8080` and upload a PDF.

## Performance & Cost Tips

| Model | Speed | Quality | VRAM | Cost |
|-------|-------|---------|------|------|
| flan-t5-base | ⭐⭐⭐⭐⭐ | ⭐⭐ | Low | Free (HF Inference API) |
| Mistral-7B | ⭐⭐⭐ | ⭐⭐⭐⭐ | Medium | Free (HF Inference API) |
| Llama-2-7b | ⭐⭐⭐ | ⭐⭐⭐⭐ | Medium | Free (HF Inference API) |
| Llama-2-13b | ⭐⭐ | ⭐⭐⭐⭐⭐ | Large | Free (HF Inference API) |
| Mixtral-8x7B | ⭐ | ⭐⭐⭐⭐⭐⭐ | Very Large | Free (HF Inference API) |

**Note:** Using HuggingFace Inference API (all models above) is **free** with rate limits. No GPU needed locally!

## Troubleshooting

### "Model not found" error
- Check spelling of model name (case-sensitive)
- Ensure model exists: https://huggingface.co/models
- Try a simpler model first (e.g., `google/flan-t5-base`)

### "Unauthorized" error
- Verify `HF_API_KEY` is set in `.env`
- Check token is read-capable
- For gated models (Llama), accept terms on HuggingFace

### Slow responses
- Use smaller models (flan-t5-base) or faster inference endpoints
- Consider reducing `max_new_tokens` in `src/helper.py` (lines ~81, ~105)

### Empty questions generated
- Model may not understand your PDF's domain
- Try a different, larger model
- Adjust temperature (lower = more deterministic)

## Example Configurations

### **⚡ Fastest (for testing)**
```python
QUESTION_GEN_MODEL = "google/flan-t5-base"
ANSWER_GEN_MODEL = "google/flan-t5-base"
EMBEDDINGS_MODEL = "sentence-transformers/all-MiniLM-L6-v2"
```

### **🎯 Balanced (recommended for most users)**
```python
QUESTION_GEN_MODEL = "mistralai/Mistral-7B-Instruct-v0.1"
ANSWER_GEN_MODEL = "mistralai/Mistral-7B-Instruct-v0.1"
EMBEDDINGS_MODEL = "sentence-transformers/all-MiniLM-L6-v2"
```

### **🏆 Highest Quality (slower)**
```python
QUESTION_GEN_MODEL = "meta-llama/Llama-2-13b-chat-hf"
ANSWER_GEN_MODEL = "meta-llama/Llama-2-7b-chat-hf"
EMBEDDINGS_MODEL = "sentence-transformers/all-mpnet-base-v2"
```

## Resources

- Browse all models: https://huggingface.co/models?pipeline_tag=text-generation
- Test models live: https://huggingface.co/spaces/stabilityai/stable-diffusion-ui
- API docs: https://huggingface.co/docs/api-inference/quicktour
