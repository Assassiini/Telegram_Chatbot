from setuptools import find_packages, setup

setup(
    name = "Generative AI Project",
    version= '0.0.0',
    author="Aditya Jha",
    author_email="",
    packages= find_packages(),
    install_requires = []
)